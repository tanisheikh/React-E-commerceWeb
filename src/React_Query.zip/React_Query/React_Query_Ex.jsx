import axios from "axios";
import React, { useState } from "react";
import "./query.css";
import { useQuery, useMutation, useQueryClient } from "react-query";
import { DataTable } from "primereact/datatable";
import { Column } from "primereact/column";
import { Button } from "primereact/button";
import { Dialog } from "primereact/dialog";

import { InputText } from "primereact/inputtext";

import loading from "./loadingGif/loading.gif";

//The useQuery hook returns a handful of objects such as isSuccess, isError, isLoading, isFetching, data, and error.
//    "start": "react-scripts start",
// Resources
//   http://localhost:4000/posts
//   http://localhost:4000/comments
//   http://localhost:4000/profile

//   Home
//   http://localhost:4000

//Type s + enter at any time to create a snapshot of the database
//Watching..
const React_Query_Ex = () => {
  const queryClient = useQueryClient();

  const [visible, setVisible] = useState(false);
  const [title, setTitle] = useState("");
  const [disc, setDics] = useState("");
  const [updateDatas, setUpdateDatas] = useState({ title: "", disc: "" });

  const fetchData = async () => {
    const response = await axios.get("http://localhost:4000/data");
    return response.data;
  };
  const { isLoading, isFetching, error, data, status } = useQuery(
    "users",
    fetchData
  );

const updatePost=async (postId,updatedD)=>{
  const response = await axios.put(`http://localhost:4000/posts/${postId}`);
  return response.data;
} 
   const mutation = useMutation((id,updatedData) => console.log("updatedData>>",updatedData,"id>>",id));


const handleSubmit = (e,rowData) => {
  console.log("e>>>",e)
  console.log("rowData>>",rowData)
  e.preventDefault();
  setUpdateDatas({title:title,disc:disc})
  console.log("updateDatas>>",updateDatas)
  mutation.mutate(rowData.id,updateDatas);
};

  if (isLoading) {
    return (
      <div>
        <img src={loading} alt="loading..." className="loading_gif" />
      </div>
    );
  }
  if (error) {
    return <div>"Error..."</div>;
  }

  //
  const footerContent = (
    <div>
      <Button
        label="Cancle"
        icon="pi pi-times"
        onClick={() => setVisible(false)}
        className="p-button-text"
      />
    </div>
  );
  const btnTemplate = (rowData) => {
    return (
      <>
        <Button
          type="button"
          icon="pi pi-user-edit"
          onClick={() => setVisible(true)}
        />
        <Dialog
          header="Header"
          visible={visible}
          style={{ width: "50vw" }}
          onHide={() => setVisible(false)}
          footer={footerContent}
        >
          <form >
            <label>Title</label>
            <span className="p-float-label">
              <InputText
                id="title"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
              />
              <label htmlFor="title">Title</label>
            </span>
            <label>Description</label>
            <span className="p-float-label">
              <InputText
                id="desc"
                value={disc}
                onChange={(e) => setDics(e.target.value)}
              />
              <label htmlFor="desc">Description</label>
            </span>

            <Button
              label="Save"
              type="submit"
              icon="pi pi-check"
              onClick={(e)=>handleSubmit(e,rowData)}
              autoFocus
            />
          </form>
        </Dialog>
      </>
    );
  };

  return (
    <div className="container">
      <div className="card">
        <DataTable value={data} tableStyle={{ minWidth: "50rem" }}>
          <Column field="id" header="Id"></Column>
          <Column field="title" header="Title"></Column>
          <Column field="body" header="Description"></Column>
          <Column
            style={{ flex: "0 0 4rem" }}
            header="edit"
            body={btnTemplate}
          ></Column>
        </DataTable>
      </div>
    </div>
  );
};

export default React_Query_Ex;
